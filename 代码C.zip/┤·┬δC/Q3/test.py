a={1:1}
b={}
c={1:2}

print